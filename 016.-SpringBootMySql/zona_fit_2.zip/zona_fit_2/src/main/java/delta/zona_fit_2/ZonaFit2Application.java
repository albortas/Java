package delta.zona_fit_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZonaFit2Application {

	public static void main(String[] args) {
		SpringApplication.run(ZonaFit2Application.class, args);
	}

}
